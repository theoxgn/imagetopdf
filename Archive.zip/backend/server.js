const express = require('express');
const multer = require('multer');
const PDFDocument = require('pdfkit');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());

// Konfigurasi multer
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage });

app.post('/convert', upload.array('images'), async (req, res) => {
  try {
    const doc = new PDFDocument({
      autoFirstPage: false,
      size: 'A4',
      margin: 50
    });

    const pdfPath = path.join(__dirname, 'output.pdf');
    const writeStream = fs.createWriteStream(pdfPath);
    doc.pipe(writeStream);

    // Definisikan ukuran halaman A4 dalam points
    const pageWidth = 595.28;
    const pageHeight = 841.89;
    const margin = 50;

    for (const file of req.files) {
      try {
        const img = fs.readFileSync(file.path);
        
        // Tambah halaman baru
        doc.addPage();

        // Hitung area yang tersedia
        const availableWidth = pageWidth - (margin * 2);
        const availableHeight = pageHeight - (margin * 2);

        // Dapatkan caption dari nama file (tanpa ekstensi)
        const caption = path.parse(file.originalname).name;

        // Posisi vertikal awal untuk konten
        const startY = (pageHeight - availableHeight) / 2;

        // Tambahkan gambar tepat di bawah caption
        doc.image(img, {
            fit: [availableWidth, availableHeight - 40], // Kurangi tinggi untuk caption
            align: 'center',
            x: margin,
            y: startY + 40 // Posisi setelah caption
        });

        // Tambahkan caption
        doc.fontSize(12)
           .text(caption, {
             align: 'center',
             width: availableWidth,
             x: margin,
             y: startY + 20 // Sedikit jarak dari atas
           });

        // Hapus file temporary
        fs.unlinkSync(file.path);
      } catch (imgError) {
        console.error('Error processing image:', imgError);
        continue;
      }
    }

    doc.end();

    writeStream.on('finish', () => {
      res.download(pdfPath, 'converted.pdf', (err) => {
        if (err) {
          console.error('Error downloading:', err);
          res.status(500).send('Error downloading file');
        }
        fs.unlinkSync(pdfPath);
      });
    });

  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Error converting files');
  }
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});